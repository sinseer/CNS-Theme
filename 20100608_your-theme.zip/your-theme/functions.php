<?php


      load_theme_textdomain( 'your-theme', TEMPLATEPATH . '/languages' );
      $locale = get_locale();
      $locale_file = TEMPLATEPATH . "/languages/$locale.php";
      if ( is_readable($locale_file) )
       require_once($locale_file);

      function get_page_number() {
          if ( get_query_var('paged') ) {
		print ' | ' . __( 'Page ' , 'your-theme') . get_query_var('paged');
          }
      } 
?>

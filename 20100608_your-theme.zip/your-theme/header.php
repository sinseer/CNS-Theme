<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

      <head profile="http://gmpg.org/xfn/11">
          <title><?php
              if ( is_single() ) { single_post_title(); }      
              elseif ( is_home() || is_front_page() ) { bloginfo('name'); get_page_number(); }
              elseif ( is_page() ) { single_post_title(''); }
              elseif ( is_search() ) { bloginfo('name'); print ' | Search results for ' . wp_specialchars($s); get_page_number(); }
              elseif ( is_404() ) { bloginfo('name'); print ' | Not Found'; }
              else { bloginfo('name'); wp_title('|'); get_page_number(); }
          ?></title>
		  
	
	   
      </head>

      <body>
 
 <div id="branding">
    <div id="blog-title"><span><a href="<?php bloginfo( 'url' ) ?>/" title="<?php bloginfo( 'name' ) ?>" rel="home"><?php bloginfo( 'name' ) ?></a></span></div>

	</div><!– #branding –>


<?php wp_page_menu( 'sort_column=menu_order' ); ?>

       <div id="main">
      <?php get_header(); ?>
        <div id="container">
         <div id="content">

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<h3 class="entry-title"><?php the_title(); ?></h3>


<?php the_content(); ?>
      <?php wp_link_pages('before=<div class="page-link">' . __( 'Pages:', 'your-theme' ) . '&after=</div>') ?>

          <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          </div><!– #post-<?php the_ID(); ?> –>  


<div id="nav-above" class="navigation">
     <div class="nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav">&laquo;</span> %title' ) ?></div>
     <div class="nav-next"><?php next_post_link( '%link', '%title <span class="meta-nav">&raquo;</span>' ) ?></div>
    </div><!– #nav-above –>


         
         </div><!– #content –>  
        </div><!– #container –>
      <?php get_sidebar(); ?>
      <?php get_footer(); ?>


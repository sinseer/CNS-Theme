<span>&laquo;</span> 
<?php next_post_link('<span class="next">%link</span>'); ?> 
<span>|</span> 
<?php previous_post_link('<span class="prev">%link</span>'); ?> 
<span>&raquo;</span>
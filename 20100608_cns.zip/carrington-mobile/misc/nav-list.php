<span>&laquo;</span>
<span class="next"><?php previous_posts_link('Previous'); ?></span>
<span>|</span>
<span class="prev"><?php next_posts_link('Next'); ?></span>
<span>&raquo;</span>